package in.ineuron.service;

import java.util.List;

public interface IPersonMgmtService {

	public List<Object[]> fetchDataByJoinsUsingParent();

}
