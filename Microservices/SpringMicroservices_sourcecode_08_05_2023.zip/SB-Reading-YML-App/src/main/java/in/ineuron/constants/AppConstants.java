package in.ineuron.constants;

public class AppConstants {
	public static final String WELCOME_MSG = "welcomeMsg";
	public static final String GREET_MSG = "greetMsg";
	public static final String TEST_MSG = "testMsg";
}
